<?php

declare(strict_types=1);

namespace FeedIo\Adapter;

class NotFoundException extends HttpRequestException
{
}
